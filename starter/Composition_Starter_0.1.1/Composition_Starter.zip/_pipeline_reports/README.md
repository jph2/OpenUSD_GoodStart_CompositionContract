# Preset provenance

This bundle copies authored files; packaging is not USD or Kit acceptance. The source example's historical build report is deliberately excluded. Inventory hashes describe the packaged bytes only. Optional roles are empty authoring slots.
