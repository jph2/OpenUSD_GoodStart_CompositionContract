# Composition Contracts starter 0.1.1

Open `SceneROOT_STARTER.usda` using `Open_In_Kit.ps1` (defaults to STARTER in this bundle). The launcher needs an existing compatible Kit installation; provide -KitExe and -AppConfig if it cannot detect a running Kit application. It installs no applications.

Opinion is the default editable target; other persistent layers are protected. Save retains Opinion edits. Demo roots share their own Opinion; Starter is independent. Starter includes demo assets and optional layer slots: remove or mute what you do not need. See README.md for details. Source-repository links in copied documentation may require https://github.com/jph2/OpenUSD_Composition_Contracts .

Keep asset/resource paths relative and copy the whole package for an independent project. Contracts are in `_contracts/reference`. This project was developed with AI assistance, including OpenAI Codex; human review and verification remain required.
